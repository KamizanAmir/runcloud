

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Workspace')); ?></div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <h1>Your current Workspace :</h1><br><br>
                    <?php $__currentLoopData = $todos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $todo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <b><?php echo e($todo -> title); ?></b>
                            <a href="/create/task" style="margin-left:15px">Add task</a>
                            <a> | </a>
                            <a href="" style="margin-left:5px">Delete Workspace</a>
                            <a style="margin-left:10px; font-family:cursive; font-size:10px">( <?php echo e($todo -> created_at); ?> )</a>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <br><br>
                    <div>
                        Press this button to add more workspace 
                        <a href="/create" class="btn btn-primary">+</a>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\KamizanDev\runcloud\resources\views/todo/output.blade.php ENDPATH**/ ?>