

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header" style="text-align:center; font-family:cursive;"><?php echo e(__('Task Progression')); ?></div>
                <div style="display:block; justify-content:center;" class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <div style="text-align:center">
                    <?php $__currentLoopData = $todos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $todo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <h1 style="font-family:cursive"><?php echo e($todo->title); ?></h1><br>
                    <h3>
                        <?php if (isset($component)) { $__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975 = $component; } ?>
<?php $component = App\View\Components\Alert::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Alert::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975)): ?>
<?php $component = $__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975; ?>
<?php unset($__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975); ?>
<?php endif; ?>
                    </h3>
                    <form action="/upload/task" method="post">
                        <?php echo csrf_field(); ?>
                        <div style="width:80%" class="row mb-3">
                            <label for="title" style="font-size:16px; font-family:cursive;" 
                            class="col-md-4 col-form-label text-md-end"><?php echo e(__('Title')); ?></label>
                            <div style="display:flex; justify-content:center;" class="col-md-6">
                                <div class="input-group">
                                    <input placeholder="Write a simple title" style="text-align:center; 
                                    font-family:cursive;" type="text"
                                        class="form-control2" name="title"
                                        required/>
                                </div>
                            </div>
                            <label for="title" style="font-size:16px; font-family:cursive;" 
                            class="col-md-4 col-form-label text-md-end"><?php echo e(__('Subject')); ?></label>
                            <div style="display:flex; justify-content:center;" class="col-md-6">
                                <div class="input-group">
                                    <input placeholder="Write a simple title" style="text-align:center; 
                                    font-family:cursive; padding:2.5rem 0.75rem;" type="text"
                                        class="form-control2" name="subject"
                                        required/>
                                </div>
                            </div>
                            <label for="title" style="font-size:16px; font-family:cursive;" 
                            class="col-md-4 col-form-label text-md-end"><?php echo e(__('Due Date')); ?></label>
                            <div style="display:flex; justify-content:center;" class="col-md-6">
                                <div class="input-group">
                                    <span class="input-group-addon datepicker">
                                        <h1 class="fas fa-calendar"></h1> <!-- FontAwesome calendar icon -->
                                    </span>
                                    <input placeholder="Click the calendar icon." style="text-align:center; font-family:cursive;" 
                                        type="text" class="form-control2" name="due_date" required
                                        data-date-format="yyyy-mm-dd" id="due_date" readonly>
                                </div>
                            </div>
                        </div>
                        <script>
                            $(document).ready(function () {
                                // Target input fields with the 'datepicker' class and apply the datepicker widget
                                $('.datepicker').datepicker({
                                    todayHighlight: true, // Highlighting Today's Date so the user much aware of their due date
                                    startDate : 'tomorrow', // Force user to start the calendar within today, since no due to past right??
                                    autoclose: true, // Automatically close the datepicker when a date is selected
                                    format: 'yyyy-mm-dd', // Set the date format
                                }).on('changeDate', function (e) {
                                    // When a date is selected, update the value of the input field
                                    $('#due_date').val(e.format());
                                });
                            });
                        </script>
                        <style>
                            /* Custom CSS to change the color of the highlighted date */
                            .today {
                                background-color: yellow;
                                color: red; /* Optional: Change text color */
                            }
                        </style>
                        <button style="background-color:#3982c3; color:white;
                            display:block; font-size:18px; font-family:cursive; width:50%;" 
                            class="btn btn-outline-secondary" type="submit">Create</button><br>
                    <hr style="margin-bottom: 3em;"/>
                    </form>
                    
                    <h1 style="font-family:cursive">Your current Task :</h1><br><br>
                    <?php $counter = 1 ?>
                    <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <b><?php echo e($counter); ?> :</b>
                            <b style="font-family:cursive; margin-left:5px;"><?php echo e($task -> title); ?></b>
                            <a href="/create/task" style="margin-left:15px; font-family:cursive;">Edit</a>
                            <a href="/create/task" style="margin-left:15px; font-family:cursive;">Mark as Finish</a>
                            <!--should change the isFinish attribute to 1 and show when he mark the task as
                            finish or when the value change to 1 from 0 !-->
                            <!--<a> | </a>
                            <a href="" style="margin-left:5px; font-family:cursive;">Complete</a>
                            <a style="margin-left:10px; font-family:italic; font-size:12px">( <?php echo e($task -> created_at); ?> )</a>!-->
                        </li>
                        <?php $counter++ ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <br><br>
                    <div style="display:flex; justify-content:center">
                        <a href="/home" style="background-color:#3982c3; color:white;
                            display:block; font-size:18px; font-family:cursive; width:50%;" 
                            class="btn btn-outline-secondary">
                            <?php echo e(__('Back')); ?>

                        </a>
                    </div>
                </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\KamizanDev\runcloud\resources\views/task/create.blade.php ENDPATH**/ ?>