

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header" style="text-align:center; font-family:cursive;"><?php echo e(__('Workspace')); ?></div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <div style="text-align:center">
                    <h1 style="font-family:cursive">Create your workspace</h1><br>
                    <h3>
                        <?php if (isset($component)) { $__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975 = $component; } ?>
<?php $component = App\View\Components\Alert::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Alert::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975)): ?>
<?php $component = $__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975; ?>
<?php unset($__componentOriginald4c8f106e1e33ab85c5d037c2504e2574c1b0975); ?>
<?php endif; ?>
                    </h3>
                    <form action="/upload" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="input-group">
                            <input type="text" name="title" class="form-control2" style="text-align:center; width:50%" placeholder="Eg : Workspace 1" required/>
                            <button type="submit" class="btn btn-outline-secondary">Create</button>
                        </div>
                    </form><br>
                    <hr/><br>
                    <h1 style="font-family:cursive">Your current Workspace :</h1><br><br>
                    <?php $counter = 1 ?>
                    <?php $__currentLoopData = $todos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $todo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <b><?php echo e($counter); ?> :</b>
                            <b style="font-family:cursive; margin-left:5px;"><?php echo e($todo -> title); ?></b>
                            <a href="<?php echo e(asset('/' . $todo->id . '/create/task')); ?>" style="margin-left:15px; font-family:cursive;">Add or View task</a>
                            <a> | </a>
                            <a href="" style="margin-left:5px; font-family:cursive;">Delete Workspace</a>
                            <a style="margin-left:10px; font-family:italic; font-size:12px">( <?php echo e($todo -> created_at); ?> )</a>
                        </li>
                        <?php $counter++ ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <br><br>
                </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\KamizanDev\runcloud\resources\views/todo/create.blade.php ENDPATH**/ ?>