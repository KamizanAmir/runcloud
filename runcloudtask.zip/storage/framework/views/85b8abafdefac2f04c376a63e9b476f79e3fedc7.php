<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header" style="text-align:center; font-family:cursive;"><?php echo e(__('Login')); ?></div>
                
                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('login')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="row mb-3">
                            <label for="email" style="font-size: 16px; font-family:cursive;" 
                            class="col-md-4 col-form-label text-md-end" 
                            required><?php echo e(__('Email Address or Username')); ?></label>
                            <div class="col-md-6">
                                <input id="username" style="text-align:center; font-family:cursive" placeholder="Eg : example@123.com or example123" type="username" class="form-control 
                                <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="username" 
                                value="<?php echo e(old('username')); ?>" required autocomplete="username" autofocus>
                                <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label for="password" style="font-size:16px; font-family:cursive;" 
                            class="col-md-4 col-form-label text-md-end"><?php echo e(__('Password')); ?></label>
                            <div class="col-md-6">
                                <div class="input-group">
                                    <input placeholder="*******" style="text-align:center; 
                                    font-family:cursive;" id="password" type="password"
                                        class="form-control2 <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password"
                                        required autocomplete="current-password">
                                    <button type="button" style="font-family:cursive;" id="show-password-toggle" 
                                    class="btn btn-outline-secondary">
                                        Show Password
                                    </button>
                                </div>
                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        <hr style="margin-bottom: 3em;"/>
                        </div>
                        <div class="row mb-3">
                            <div style="width:100%" class="col-md-6 offset-md-4">
                                <div class="form-check">
                                    <input class="form-check-input" style="border-color: blue; border-style: solid; border-width: thin;" 
                                        type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>/>
                                    <label class="form-check-label" for="remember">
                                        <a style="margin:right:10em; font-size: 15px; font-family: cursive;"> <?php echo e(__('Remember Me')); ?></a>
                                    </label>
                                    <a style="margin-left:1em; margin-right:1em;"> | </a>
                                    <a style="font-size: 15px; font-family: cursive;">Don't have an account yet? 
                                        <?php if(Route::has('register')): ?>
                                            <a style="font-size: 15px; font-family: cursive;" href="<?php echo e(route('register')); ?>">
                                                <?php echo e(__('Register')); ?>

                                            </a>
                                            <span style="font-size: 15px; font-family: cursive;">here.</span>
                                        <?php endif; ?>
                                    </a>
                                    <a style="margin-left:1em; margin-right:1em;"> | </a>
                                    <?php if(Route::has('password.request')): ?>
                                        <a style="font-size: 15px; font-family: cursive;" href="<?php echo e(route('password.request')); ?>">
                                            <?php echo e(__('Forgot Your Password?')); ?>

                                        </a>
                                    <?php endif; ?>
                                </div>
                                <br>
                                <br>
                                <div>
                                    <button style="background-color:#3982c3; color:white; display:flex; justify-content:center;
                                    font-size:18px; font-family:cursive; width:50%;" 
                                    class="btn btn-outline-secondary" type="submit">
                                        <?php echo e(__('Login')); ?>

                                    </button>
                                </div>
                            </div>
                        </div>


                        <style>
                            #show-password-toggle {
                                color: #333; /* Change this color to the desired color */
                            }
                        </style>
                        <script>
                            document.addEventListener("DOMContentLoaded", function() {
                                const passwordInput = document.getElementById("password");
                                const showPasswordToggle = document.getElementById("show-password-toggle");
                                    
                                showPasswordToggle.addEventListener("click", function() {
                                    if (passwordInput.type === "password") {
                                        passwordInput.type = "text";
                                        showPasswordToggle.textContent = "Hide Password";
                                    } else {
                                        passwordInput.type = "password";
                                        showPasswordToggle.textContent = "Show Password";
                                    }
                                });
                            });
                        </script>
                    </form>
                </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\KamizanDev\runcloud\resources\views/auth/login.blade.php ENDPATH**/ ?>