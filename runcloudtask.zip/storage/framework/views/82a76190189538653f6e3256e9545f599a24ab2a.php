

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Add workspace')); ?></div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <div>
                        <a href="<?php echo e(route('home')); ?>" class="btn btn-primary"><=</a>
                    </div>
                    <h1>Create your workspace</h1>
                    <form action ="/upload" method="post">
                        <input type="text" name="workspace"/>
                        <input type="submit" value="Create"/>
                    </form>

                    <?php echo e(__('Add task by press the "+" button below')); ?>

                    <div>
                        <a href="<?php echo e(route('todolist')); ?>" class="btn btn-primary">+</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\KamizanDev\runcloud\resources\views/workspace.blade.php ENDPATH**/ ?>